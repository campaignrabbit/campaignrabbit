
A PHP Client Library to integrate your e-commerce site and campaignrabbit